<?php
 if(isset($_GET['ok'])){
       $code=$_GET['ok'] ;           //contenue du variable matricule d'url affecter dans une nouvvel variable
       		
      $con=new PDO('mysql:host=localhost;dbname=Liste_employers','root','root');

              $sql="SELECT*FROM Employers WHERE Matricule=$code"; 
                   $stmt=$con->query($sql);
                      $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
         			 	
    }

?>
<!doctype html>
<html>
<head><title></title>
    <link rel="stylesheet" type="text/css" href="ajoutemployer.css">
</head>
<body>
<?php
    if(isset($_GET['ok'])){
        if($_GET['ok']==true){
            echo("Employer ajouter ave succes");
        }
    }
?>

    <div id='body'>
    <div class='entete'><h1>Formulaire De Modification des Enregistrements</h1>
        <a href='listemployer.php'><button>Allez à la fiche d'enregistrement</button></a>
        </div>
        <h2 ><span class='erreur'><?php if (isset($erreurS)){echo $erreurS;} ?>
        <?php if (isset($erreurS2)){echo $erreurS2;} ?>
        <?php if (isset($erreurE)){echo $erreurE;}?>
        <?php if (isset($erreurT)){echo $erreurT ;}?>
        <?php if (isset($erreurD)){echo $erreurD;}?></span></h2>

<?php foreach($rows as $rows): ?>  
        <form action="tmodifemployer.php?ok=<?php echo $rows['Matricule'] ?>" method="POST">
    
    <table>
        <tr><th colspan="2"><legend>Modification d'ENREGISTREMENT</legend></th></tr>
        <tr>
            <td><label for="matricule">Matricule: </label></td>
            <td><input type="text" name="matricule"  value="<?php echo $rows['Matricule'] ?>" class="field" ></td>
        </tr>
        <tr>
            <td><label for="prenom">Prenom: </label></td>
            <td><input type="text" name="prenom" value="<?php echo $rows['Prenom'] ?>"class="field"></td>
        </tr>
        <tr>
            <td><label for="nom">Nom: </label></td>
            <td><input type="text" name="nom"value="<?php echo $rows['Nom'] ?>" class="field"></td>
        </tr>
        <tr>
            <td><label for="datenaiss">Date de Naissance: </label></td>
            <td><input type="text" name="datenaiss" value="<?php echo $rows['Date_de_naissance'] ?>" class="field"></td>
        </tr>
        <tr>
            <td><label for="salaire">Salaire: </label></td>
            <td><input type="text" name="salaire" value="<?php echo $rows['Salaire'] ?>" class="field"></td>
        </tr>
        <tr>
            <td><label for="telephone">Telephone: </label></td>
            <td><input type="text" name="telephone" value="<?php echo $rows['Telephone'] ?>" class="field"></td>
        </tr>
        <tr>
            <td><label for="email">E_mail: </label></td>
            <td><input type="text" name="email" value="<?php echo $rows['Email'] ?>" class="field"></td>
        </tr>
        <tr style="colspans:2">
        <td colspan="2"style="text-align:center">
            <button type="submit" name="valider" class="btn">Valider</button>
            <button type="reset"  name="annuler" class="btn">Annuler</button>
         </td>
        </tr>
        
    </table>

</form>
<?php endforeach ?>
</div>
</body>
</html>

