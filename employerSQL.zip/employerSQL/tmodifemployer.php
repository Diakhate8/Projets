<?php
    if(isset($_GET['ok'])){
       $code=$_GET['ok'] ;           //contenue du variable matricule d'url affecter dans une nouvvel variable
       
	 $con=new PDO('mysql:host=localhost;dbname=Liste_employers','root','root');
		$req="UPDATE Employers SET(Prenom,Nom,Date_de_naissance,Email,Salaire,Telephone) VALUES('$prenom','$nom','$datenaiss','$email','$salaire','$telephone') WHERE Matricule=$code";
			
				$con->exec($req);
				header('location:listemployer.php');
	
}
	
?>

