<?php
    if(isset($_POST['valider'])){
       $code=$_GET['ok'] ;  
		$prenom=trim($_POST['prenom']);           
                $nom=trim($_POST['nom']);                    
                $datenaiss=$_POST['datenaiss'];     
                $email=$_POST['email'];               
                $salaire=$_POST['salaire'];          
                $telephone=$_POST['telephone'];          //contenue du variable matricule d'url affecter dans une nouvvel variable
       
	 $con=new PDO('mysql:host=localhost;dbname=Liste_employers','root','root');
		$req="UPDATE Employers SET Prenom='$prenom',Nom='$nom',Date_de_naissance='$datenaiss',Email='$email',Salaire='$salaire',Telephone='$telephone' WHERE Matricule=$code";
			
				$con->exec($req);
				header('location:listemployer.php');
	
}
	
?>

