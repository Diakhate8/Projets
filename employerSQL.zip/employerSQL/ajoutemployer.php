<?php

        if(isset($_POST['enregistrer'])){
            
            if(empty($_POST['prenom']) || empty($_POST['nom'])
                    || empty($_POST['datenaiss']) || empty($_POST['salaire']) || empty($_POST['telephone']) 
                    || empty($_POST['email']) ){echo "Veuillez saisire toutes les champs";   }
                
            else
            {   
                $prenom=trim($_POST['prenom']);           
                $nom=trim($_POST['nom']);                    
                $datenaiss=$_POST['datenaiss'];     
                $email=$_POST['email'];               
                $salaire=$_POST['salaire'];          
                $telephone=$_POST['telephone']; 
        
                    //controle
              //  if(strptime($datenaiss,"%m/%d/%y")){
                    if(filter_var($email, FILTER_VALIDATE_EMAIL)){  
                        if(is_numeric($salaire)){
                            if($salaire>=25000 && $salaire<=2000000){
                                if(preg_match('#^(78||77||76||70)[0-9]{7}$#',$telephone)){

                                    //connexion a la BD   
                                   $con=new PDO('mysql:host=localhost;dbname=Liste_employers','root','root') or die('Error');
                                           
				//insertion des donnees                          
             $req="INSERT INTO Employers (Prenom,Nom,Date_de_naissance,Email,Salaire,Telephone) VALUES('$prenom','$nom','$datenaiss','$email','$salaire','$telephone')";

					//executer la requete dans la base
                                         $con->exec($req);
					//redirection
			//	header('location:listemployer.php');


                                }else{$erreurT="Entrez un numero valide"; }
                            }else{ $erreurS2="Entrez un salaire";}                   
                        }else{$erreurS="Entrez un salaire valide";  }
                    } else{$erreurE="email non valide";           } 
              // }else{$erreurD="La date n'est pas valide";  }
        
        
            }                             //INSERT INTO table(champ1, champ2, champ3) VALUES('valeur1', 'valeur2', 'valeur3')
        
           
        }
?>

<!doctype html>
<html>
<head><title>ajoutemployer</title>
    <link rel="stylesheet" type="text/css" href="ajoutemployer.css">
</head>
<body>
<?php
    if(isset($_GET['ok'])){
        if($_GET['ok']==true){
            echo("Employer ajouter ave succes");
        }
    }
?>

<div id='body'>
    <div class='entete'><h1>Formulaire D'enregistrement  des Employers</h1>
        <a href='listemployer.php'><button>Allez à la liste des enregistrements</button></a>
        </div>
        <h2 ><span class='erreur'><?php if (isset($erreurS)){echo $erreurS;} ?>
        <?php if (isset($erreurS2)){echo $erreurS2;} ?>
        <?php if (isset($erreurE)){echo $erreurE;}?>
        <?php if (isset($erreurT)){echo $erreurT ;}?>
        <?php if (isset($erreurD)){echo $erreurD;}?></span></h2>


    <form method="POST"  action="">
    
            <table>
                <tr><th colspan="2"><legend>ENREGISTREMENT</legend></th></tr>
                <tr>
                    <td><label for="matricule">Matricule: </label></td>
                    <td><input type="text" name="matricule" class="field" ></td>
                </tr>
                <tr>
                    <td><label for="prenom">Prenom: </label></td>
                    <td><input type="text" name="prenom" class="field"></td>
                </tr>
                <tr>
                    <td><label for="nom">Nom: </label></td>
                    <td><input type="text" name="nom" class="field"></td>
                </tr>
                <tr>
                    <td><label for="datenaiss">Date de Naissance: </label></td>
                    <td><input type="text" name="datenaiss" class="field" placeholde="0000-00-00"></td>
                </tr>
                <tr>
                    <td><label for="salaire">Salaire: </label></td>
                    <td><input type="text" name="salaire" class="field"></td>
                </tr>
                <tr>
                    <td><label for="telephone">Telephone: </label></td>
                    <td><input type="text" name="telephone" class="field"></td>
                </tr>
                <tr>
                    <td><label for="email">E_mail: </label></td>
                    <td><input type="text" name="email" class="field"></td>
                </tr>
                <tr style="colspans:2">
                    <td colspan="2"style="text-align:center">
                    <button type="submit" name="enregistrer" class="btn">enregistrer</button>
                    </td>
                </tr>
                
                
            </table>
        
    </form>
</div>
</body>
</html>
