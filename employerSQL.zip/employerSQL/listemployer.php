<?php
      $con=new PDO('mysql:host=localhost;dbname=Liste_employers','root','root');

              $sql="SELECT*FROM Employers"; 
                   $stmt=$con->query($sql);
                      $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
                        //  var_dump($rows); //affichage cle valeurs  
			//die();juste le php sera afficher                    


?>


<html>
<head><title>listemployer</title>
<link rel="stylesheet" type="text/css" href="listemployer.css">
<script type="text/javascript" > function confirmation(){
    return confirm("Voulez vous vraiment supprimer") ;
} </script>
</head>
<body>
	<div class='entete'><h1>Liste Des Employers Enregistrés</h1>
		<a href='ajoutemployer.php'><button>Allez à la Formulaire d'enregistrement</button></a>
	 </div>
	<table>
	    <tr><th>Matricule</th><th>Prenom</th><th>Nom</th><th>Date de Naissance</th><th>E_Mail</th><th>Salaire</th>
	    <th>Telephone</th><th>action</th><th>action</th></tr>
	    <?php foreach($rows as $rows): ?>    
		    <tr>
			<td><?php echo $rows['Matricule'] ?></td>
			<td><?php echo $rows['Prenom'] ?></td>
			<td><?php echo $rows['Nom'] ?></td>
			<td><?php echo $rows['Date_de_naissance'] ?></td>
			<td><?php echo $rows['Salaire'] ?></td>
			<td><?php echo $rows['Telephone'] ?></td>
			<td><?php echo $rows['Email'] ?></td>
			<td><a href="modifemployer.php?ok=<?=$rows['Matricule']?>"><button>Modifier</button></a></td>
			<td><a href="tsupemployer.php?ok=<?=$rows['Matricule']?>" onclick="return confirmation();"><button>Suprimer</button></a></td>
		    </tr>
	    <?php endforeach ?>
	</table>
            
</body>
</html>
