<?php
if(isset($_POST['enregistrer'])){

    if( empty($_POST['prenom']) || empty($_POST['nom']) || empty($_POST['datenaiss']) || empty($_POST['salaire'])|| empty($_POST['telephone'])
            || empty($_POST['email']) ){echo "Veuillez saisire toutes les champs";   }
        
    else
    {   
        
        $prenom=$_POST['prenom'];  
        $prenom=str_replace(' ',' ',$prenom);           
        $nom=$_POST['nom'];  
        $nom=str_replace(' ','',$nom);                   
        $datenaiss=$_POST['datenaiss'];     
        $email=$_POST['email'];               
        $salaire=$_POST['salaire'];          
        $telephone=$_POST['telephone']; 

            //controle
      //  if(strptime($datenaiss,"%m/%d/%y")){
            if(filter_var($email, FILTER_VALIDATE_EMAIL)){  
                if(is_numeric($salaire)){
                    if($salaire>=25000 && $salaire<=2000000){
                        if(preg_match('#^(78||77||76||70)[0-9]{7}$#',$telephone)){

                            $db=new PDO('mysql:host=localhost;dbname=bd_employers','root','');
                            $req="INSERT INTO employers (prenom,nom,datenaiss,email,salaire,telephone) VALUES('$prenom','$nom','$datenaiss','$email','$salaire','$telephone')";
                            $db->exec($req);
                            header('location:listemployer.php');
                           

                        }else{$erreurT="Entrez un numero valide"; }
                    }else{ $erreurS2="Entrez un salaire";}                   
                }else{$erreurS="Entrez un salaire valide";  }
            } else{$erreurE="email non valide";           } 
      // }else{$erreurD="La date n'est pas valide";  }


    }                             //INSERT INTO table(champ1, champ2, champ3) VALUES('valeur1', 'valeur2', 'valeur3')

   
}
?>