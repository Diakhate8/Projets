<?php
    if(isset($_GET['ok'])){
       $code=$_GET['ok'] ;           //contenue du variable matricule d'url affecter dans une nouvvel variable
       
	 $con=new PDO('mysql:host=localhost;dbname=Liste_employers','root','root');
		$req="DELETE FROM Employers WHERE Matricule=$code";
			
				$con->exec($req);
				header('location:listemployer.php');
	
}
	
?>

